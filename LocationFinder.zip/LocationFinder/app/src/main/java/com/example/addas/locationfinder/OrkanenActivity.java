package com.example.addas.locationfinder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OrkanenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orkanen);
    }
}
